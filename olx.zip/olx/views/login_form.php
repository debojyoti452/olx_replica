<form action="login.php" method="POST">
    <fieldset>
        E-mail : <input type="text" name="email" autofocus required="required"/><br>
        Password : <input type="password" name="password" required="required"/><br/>
        <button type="submit">LOG IN</button><br/>
    </fieldset>
</form>
<div>
    or <a href="register.php">Register</a> for an account.
</div>