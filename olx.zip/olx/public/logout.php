<?php

    // configuration
    require("../models/config.php"); 

    // log out current user, if any
    logout();

    // redirect user
    redirect("/");

?>
